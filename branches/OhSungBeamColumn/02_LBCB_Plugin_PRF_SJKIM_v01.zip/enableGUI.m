function enableGUI(handles)


set(handles.PM_Axis_X1,		'enable',	'on');
set(handles.PM_Axis_Y1,		'enable',	'on');
set(handles.PM_Axis_X2,		'enable',	'on');
set(handles.PM_Axis_Y2,		'enable',	'on');
set(handles.PM_Axis_X3,		'enable',	'on');
set(handles.PM_Axis_Y3,		'enable',	'on');
set(handles.PM_Axis_X4,		'enable',	'on');
set(handles.PM_Axis_Y4,		'enable',	'on');

set(handles.CB_MovingWindow,	'enable',	'on');
set(handles.Edit_Window_Size,	'enable',	'on');


set(handles.CB_Disp_Limit1,	'enable',	'on');
set(handles.CB_Disp_Inc1,	'enable',	'on');
set(handles.CB_Forc_Limit1,	'enable',	'on');
set(handles.CB_Disp_Limit2,	'enable',	'on');
set(handles.CB_Disp_Inc2,	'enable',	'on');
set(handles.CB_Forc_Limit2,	'enable',	'on');

set(handles.EB_Max_Itr,		        'enable',	'on');
set(handles.Edit_DLmin_DOF11,	'enable',	'on');
set(handles.Edit_DLmin_DOF12,	'enable',	'on');
set(handles.Edit_DLmin_DOF13,	'enable',	'on');
set(handles.Edit_DLmin_DOF14,	'enable',	'on');
set(handles.Edit_DLmin_DOF15,	'enable',	'on');
set(handles.Edit_DLmin_DOF16,	'enable',	'on');
set(handles.Edit_DLmin_DOF21,	'enable',	'on');
set(handles.Edit_DLmin_DOF22,	'enable',	'on');
set(handles.Edit_DLmin_DOF23,	'enable',	'on');
set(handles.Edit_DLmin_DOF24,	'enable',	'on');
set(handles.Edit_DLmin_DOF25,	'enable',	'on');
set(handles.Edit_DLmin_DOF26,	'enable',	'on');

set(handles.Edit_DLmax_DOF11,	'enable',	'on');
set(handles.Edit_DLmax_DOF12,	'enable',	'on');
set(handles.Edit_DLmax_DOF13,	'enable',	'on');
set(handles.Edit_DLmax_DOF14,	'enable',	'on');
set(handles.Edit_DLmax_DOF15,	'enable',	'on');
set(handles.Edit_DLmax_DOF16,	'enable',	'on');  
set(handles.Edit_DLmax_DOF21,	'enable',	'on');
set(handles.Edit_DLmax_DOF22,	'enable',	'on');
set(handles.Edit_DLmax_DOF23,	'enable',	'on');
set(handles.Edit_DLmax_DOF24,	'enable',	'on');
set(handles.Edit_DLmax_DOF25,	'enable',	'on');
set(handles.Edit_DLmax_DOF26,	'enable',	'on');  

set(handles.Edit_DLinc_DOF11,	'enable',	'on');
set(handles.Edit_DLinc_DOF12,	'enable',	'on');
set(handles.Edit_DLinc_DOF13,	'enable',	'on');
set(handles.Edit_DLinc_DOF14,	'enable',	'on');
set(handles.Edit_DLinc_DOF15,	'enable',	'on');
set(handles.Edit_DLinc_DOF16,	'enable',	'on');  
set(handles.Edit_DLinc_DOF21,	'enable',	'on');
set(handles.Edit_DLinc_DOF22,	'enable',	'on');
set(handles.Edit_DLinc_DOF23,	'enable',	'on');
set(handles.Edit_DLinc_DOF24,	'enable',	'on');
set(handles.Edit_DLinc_DOF25,	'enable',	'on');
set(handles.Edit_DLinc_DOF26,	'enable',	'on');  

set(handles.Edit_FLmin_DOF11,	'enable',	'on');
set(handles.Edit_FLmin_DOF12,	'enable',	'on');
set(handles.Edit_FLmin_DOF13,	'enable',	'on');
set(handles.Edit_FLmin_DOF14,	'enable',	'on');
set(handles.Edit_FLmin_DOF15,	'enable',	'on');
set(handles.Edit_FLmin_DOF16,	'enable',	'on');
set(handles.Edit_FLmin_DOF21,	'enable',	'on');
set(handles.Edit_FLmin_DOF22,	'enable',	'on');
set(handles.Edit_FLmin_DOF23,	'enable',	'on');
set(handles.Edit_FLmin_DOF24,	'enable',	'on');
set(handles.Edit_FLmin_DOF25,	'enable',	'on');
set(handles.Edit_FLmin_DOF26,	'enable',	'on');

set(handles.Edit_FLmax_DOF11,	'enable',	'on');
set(handles.Edit_FLmax_DOF12,	'enable',	'on');
set(handles.Edit_FLmax_DOF13,	'enable',	'on');
set(handles.Edit_FLmax_DOF14,	'enable',	'on');
set(handles.Edit_FLmax_DOF15,	'enable',	'on');
set(handles.Edit_FLmax_DOF16,	'enable',	'on');
set(handles.Edit_FLmax_DOF21,	'enable',	'on');
set(handles.Edit_FLmax_DOF22,	'enable',	'on');
set(handles.Edit_FLmax_DOF23,	'enable',	'on');
set(handles.Edit_FLmax_DOF24,	'enable',	'on');
set(handles.Edit_FLmax_DOF25,	'enable',	'on');
set(handles.Edit_FLmax_DOF26,	'enable',	'on');

set(handles.Edit_Dtol_DOF11,	'enable',	'on');
set(handles.Edit_Dtol_DOF12,	'enable',	'on');
set(handles.Edit_Dtol_DOF13,	'enable',	'on');
set(handles.Edit_Dtol_DOF14,	'enable',	'on');
set(handles.Edit_Dtol_DOF15,	'enable',	'on');
set(handles.Edit_Dtol_DOF16,	'enable',	'on');        
set(handles.Edit_Dtol_DOF21,	'enable',	'on');
set(handles.Edit_Dtol_DOF22,	'enable',	'on');
set(handles.Edit_Dtol_DOF23,	'enable',	'on');
set(handles.Edit_Dtol_DOF24,	'enable',	'on');
set(handles.Edit_Dtol_DOF25,	'enable',	'on');
set(handles.Edit_Dtol_DOF26,	'enable',	'on');        

set(handles.Edit_Dsub_DOF11,	'enable',	'on');
set(handles.Edit_Dsub_DOF12,	'enable',	'on');
set(handles.Edit_Dsub_DOF13,	'enable',	'on');
set(handles.Edit_Dsub_DOF14,	'enable',	'on');
set(handles.Edit_Dsub_DOF15,	'enable',	'on');
set(handles.Edit_Dsub_DOF16,	'enable',	'on');
set(handles.Edit_Dsub_DOF21,	'enable',	'on');
set(handles.Edit_Dsub_DOF22,	'enable',	'on');
set(handles.Edit_Dsub_DOF23,	'enable',	'on');
set(handles.Edit_Dsub_DOF24,	'enable',	'on');
set(handles.Edit_Dsub_DOF25,	'enable',	'on');
set(handles.Edit_Dsub_DOF26,	'enable',	'on');

set(handles.PB_LBCB_Disconnect,	'enable',	'on');
set(handles.RB_Elastic_Deformation_ON,		'enable',	'on');
set(handles.RB_Elastic_Deformation_OFF,		'enable',	'on');
set(handles.RB_Disp_Refine_ON,			'enable',	'on');
set(handles.RB_Disp_Refine_OFF,			'enable',	'on');
set(handles.RB_Disp_Mesurement_LBCB,		'enable',	'on');
set(handles.RB_Disp_Mesurement_External,	'enable',	'on');